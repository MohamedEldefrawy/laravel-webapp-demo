<?php

namespace App\Dto;

class DocumentDto
{

    private string $link;
    private string $name;
    private string $type;
    private int $uploadedBy;
    private int $patientId;

    /**
     * @return string
     */
    public function getLink(): string
    {
        return $this->link;
    }

    /**
     * @param string $link
     */
    public function setLink(string $link): void
    {
        $this->link = $link;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     */
    public function setType(string $type): void
    {
        $this->type = $type;
    }

    /**
     * @return int
     */
    public function getUploadedBy(): int
    {
        return $this->uploadedBy;
    }

    /**
     * @param int $uploadedBy
     */
    public function setUploadedBy(int $uploadedBy): void
    {
        $this->uploadedBy = $uploadedBy;
    }

    /**
     * @return int
     */
    public function getPatientId(): int
    {
        return $this->patientId;
    }

    /**
     * @param int $patientId
     */
    public function setPatientId(int $patientId): void
    {
        $this->patientId = $patientId;
    }

}

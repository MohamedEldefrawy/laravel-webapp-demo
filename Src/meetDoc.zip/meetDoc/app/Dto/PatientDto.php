<?php

namespace App\Dto;

class PatientDto
{

    private int $id;
    private string $email;
    private string $name;
    private string $password;
    private float $weight;
    private float $height;
    private string $gender;
    private int $age;
    private string $bloodType;
    private string $firstName;
    private string $lastName;
    private int $created_by;
    private array $symptoms;
    private string $profileImage;
    private array $documents;


    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return array
     */
    public function getSymptoms(): array
    {
        return $this->symptoms;
    }

    /**
     * @param array $symptoms
     */
    public function setSymptoms(array $symptoms): void
    {
        $this->symptoms = $symptoms;
    }

    /**
     * @return string
     */
    public function getProfileImage(): string
    {
        return $this->profileImage;
    }

    /**
     * @param string $profileImage
     */
    public function setProfileImage(string $profileImage): void
    {
        $this->profileImage = $profileImage;
    }

    /**
     * @return array
     */
    public function getDocuments(): array
    {
        return $this->documents;
    }

    /**
     * @param array $documents
     */
    public function setDocuments(array $documents): void
    {
        $this->documents = $documents;
    }

    /**
     * @return int
     */
    public function getCreatedBy(): int
    {
        return $this->created_by;
    }

    /**
     * @param int $created_by
     */
    public function setCreatedBy(int $created_by): void
    {
        $this->created_by = $created_by;
    }

    /**
     * @return string
     * @author Mohamed Eldefrawy
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @param string $email
     * @author Mohamed Eldefrawy
     */
    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    /**
     * @return string
     * @author Mohamed Eldefrawy
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     * @author Mohamed Eldefrawy
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return string
     * @author Mohamed Eldefrawy
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    /**
     * @param string $password
     * @author Mohamed Eldefrawy
     */
    public function setPassword(string $password): void
    {
        $this->password = $password;
    }

    /**
     * @return float
     * @author Mohamed Eldefrawy
     */
    public function getWeight(): float
    {
        return $this->weight;
    }

    /**
     * @param float $weight
     * @author Mohamed Eldefrawy
     */
    public function setWeight(float $weight): void
    {
        $this->weight = $weight;
    }

    /**
     * @return float
     * @author Mohamed Eldefrawy
     */
    public function getHeight(): float
    {
        return $this->height;
    }

    /**
     * @param float $height
     * @author Mohamed Eldefrawy
     */
    public function setHeight(float $height): void
    {
        $this->height = $height;
    }

    /**
     * @return string
     * @author Mohamed Eldefrawy
     */
    public function getGender(): string
    {
        return $this->gender;
    }

    /**
     * @param string $gender
     * @author Mohamed Eldefrawy
     */
    public function setGender(string $gender): void
    {
        $this->gender = $gender;
    }

    /**
     * @return int
     * @author Mohamed Eldefrawy
     */
    public function getAge(): int
    {
        return $this->age;
    }

    /**
     * @param int $age
     * @author Mohamed Eldefrawy
     */
    public function setAge(int $age): void
    {
        $this->age = $age;
    }

    /**
     * @return string
     * @author Mohamed Eldefrawy
     */
    public function getBloodType(): string
    {
        return $this->bloodType;
    }

    /**
     * @param string $bloodType
     * @author Mohamed Eldefrawy
     */
    public function setBloodType(string $bloodType): void
    {
        $this->bloodType = $bloodType;
    }

    /**
     * @return string
     * @author Mohamed Eldefrawy
     */
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * @param string $firstName
     * @author Mohamed Eldefrawy
     */
    public function setFirstName(string $firstName): void
    {
        $this->firstName = $firstName;
    }

    /**
     * @return string
     * @author Mohamed Eldefrawy
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * @param string $lastName
     * @author Mohamed Eldefrawy
     */
    public function setLastName(string $lastName): void
    {
        $this->lastName = $lastName;
    }


}

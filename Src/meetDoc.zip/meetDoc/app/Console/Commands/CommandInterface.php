<?php

namespace App\Console\Commands;

interface CommandInterface
{
    public function executeCommand();
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\DepartmentService;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    private DepartmentService $departmentService;
    public function __construct()
    {
        $this->departmentService = new DepartmentService();

    }

    public function departments(Request $request){
        return $this->departmentService->get_all();
    }
}

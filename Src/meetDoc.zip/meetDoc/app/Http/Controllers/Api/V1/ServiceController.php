<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\ServicesService;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    private ServicesService $servicesService;
    public function __construct()
    {
        $this->servicesService= new ServicesService();
    }


    public function services(Request $request){
        return  $this->servicesService->get_all();
    }
}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\DocumentRequest;
use App\Services\DocumentService;
use App\Services\S3Service;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class DocumentController extends Controller
{
    private DocumentService $documentService;

    public function __construct()
    {
        $this->documentService = new DocumentService();
    }


    /**
     * @param $patientId
     * @return AnonymousResourceCollection
     * @author Mohamed Eldefrawy
     *
     *
     *  * @OA\Get(
     * path="/api/documents/{id}",
     * summary="Get Patient documents by patient id",
     * security={
     *      {"bearer_token":{}},
     *  },
     * @OA\Parameter(
     *    name="id",
     *    in="path",
     *    description="ID of Patient",
     *    required=true,
     *    example="1",
     * ),
     * @OA\Response(
     *    response=200,
     *    description="All Patient documents returned successfully",
     *     @OA\MediaType(
     *              mediaType="application/json",
     *          )
     *     )
     * )
     */
    public function getDocuments($patientId): AnonymousResourceCollection
    {
        return $this->documentService->getPatientDocuments($patientId);
    }

    /**
     * @param DocumentRequest $request
     * @return array
     * @author Mohamed Eldefrawy
     * @OA\Post(
     *   path="/api/upload",
     *   tags={"Upload Documents"},
     *   summary="Upload Document to user",
     *      @OA\Response(
     *      response=201,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   )
     * )
     *
     */
    public function upload(DocumentRequest $request)
    {
        $s3Service = new S3Service();
        return $s3Service->uploadDocument($request->documents, $request->patientId, $request->createdBy);
    }

}

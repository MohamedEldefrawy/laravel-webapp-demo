<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\ClinicService;
use Illuminate\Http\Request;

class ClinicController extends Controller
{

    private ClinicService $clinicService;
    public function __construct()
    {
        $this->clinicService= new ClinicService();
    }


    public function clinics(Request $request){
        return  $this->clinicService->get_all();
    }
}

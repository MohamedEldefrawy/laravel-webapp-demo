<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\SymptomService;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class SymptomController extends Controller
{
    private SymptomService $symptomService;

    public function __construct()
    {
        $this->symptomService = new SymptomService();
    }


    /**
     * @param $id
     * @return AnonymousResourceCollection
     * @author Mohamed Eldefrawy
     *
     * @OA\Get(
     * path="/api/symptoms/{id}",
     * summary="Get Patient Symptoms by patient id",
     * security={
     *      {"bearer_token":{}},
     *  },
     * @OA\Parameter(
     *    name="id",
     *    in="path",
     *    description="ID of Patient",
     *    required=true,
     *    example="1",
     * ),
     * @OA\Response(
     *    response=200,
     *    description="All Patient Symptoms returned successfully",
     *     @OA\MediaType(
     *              mediaType="application/json",
     *          )
     *     )
     * )
     *
     */
    public function getSymptoms($id): AnonymousResourceCollection
    {
        return $this->symptomService->getSymptomsOfPatient($id);
    }
}

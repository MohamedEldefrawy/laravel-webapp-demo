<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\NoteService;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class NoteController extends Controller
{
    private NoteService $noteService;

    public function __construct()
    {
        $this->noteService = new NoteService();
    }

    /**
     * @param $id
     * @return AnonymousResourceCollection
     * @author Mohamed Eldefrawy
     *
     *
     * @OA\Get(
     * path="/api/notes/{id}",
     * summary="Get Patient notes by patient id",
     * security={
     *      {"bearer_token":{}},
     *  },
     * @OA\Parameter(
     *    name="id",
     *    in="path",
     *    description="ID of Patient",
     *    required=true,
     *    example="1",
     * ),
     * @OA\Response(
     *    response=200,
     *    description="All Patient notes returned successfully",
     *     @OA\MediaType(
     *              mediaType="application/json",
     *          )
     *     )
     * )
     *
     */
    public function getNotes($id): AnonymousResourceCollection
    {
        return $this->noteService->getNotesOfPatient($id);
    }
}

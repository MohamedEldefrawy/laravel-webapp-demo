<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Services\AppointmentService;
use Illuminate\Http\Request;


class AppointmentController extends Controller
{

    private AppointmentService $appointmentService;
    public function __construct()
    {
        $this->appointmentService= new AppointmentService();
    }

    public function appointments(Request $request)
    {
        return [
            'dataTable' => $this->appointmentService->get_all(),
            'startDate'=> Appointment::all()->pluck('start_date_time'),


        ] ;
    }



}

<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\OtpService;
use App\Services\UserService;
use Illuminate\Http\Request;

class UserController extends Controller
{
    //Creates the OTP
    //by Ahmed Abdelaty
    //Edited on june 4th
    public function CreateOtp(Request $request){
        return OtpService::CreateOtp($request);
    }

    //Verifies the OTP
    //by Ahmed Abdelaty
    //Edited on june 4th
    public function ValidateOtp(Request $request){
        return OtpService::ValidateOtp($request);
    }

    //Setting a new password
    //by Ahmed Abdelaty
    public function SetPassword(Request $request){
        return UserService::SetPassword($request);
    }
}

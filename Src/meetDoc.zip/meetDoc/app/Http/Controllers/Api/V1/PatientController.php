<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreatePatientRequest;
use App\Http\Resources\PatientResource;
use App\Models\Clinic;
use App\Models\ClinicPatient;
use App\Models\Patient;
use App\Models\User;
use App\Services\OtpService;
use App\Services\PatientService;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    private PatientService $patientService;

    public function __construct()
    {
        $this->patientService = new PatientService();
    }

    /**
     * get patients controller
     * @return array
     * @author Abdulla Hegab
     */
    public function getPatients(): array
    {
        $getAllPatients = Patient::get();

        return [
            'allPatients' => $getAllPatients,
        ];

    }

    /**
     * create patient
     * @param CreatePatientRequest $request
     * @return array
     * @author Abdulla Hegab
     */
    public function createPatient(CreatePatientRequest $request): array
    {
        $fields = $request->validate([
            'firstName' => 'required|string',
            'lastName' => 'required|string',
            'clinicCode' => 'required|string',
            'phone' => 'required',
        ]);

        $newUser = User::create([
            'name' => $fields['phone'],
        ])->assignRole("Patient");

        $newPatient = Patient::create([
            'first_name' => $fields['firstName'],
            'last_name' => $fields['lastName'],
            'user_id' => $newUser->id,
            'created_by' => $newUser->id,
        ]);

        $clinic_id = Clinic::where('clinicCode', $request->clinicCode)->first()->id;

        $clinicPatientRelation = ClinicPatient::create([
            'patient_code' => $fields['clinicCode'],
            'created_by' => $newUser->id,
            'patient_id' => $newPatient->id,
            'clinic_id' => $clinic_id,
        ]);
//            ;

        $otp_number = OtpService::CreateOtp($request);

        return ([
            'status' => true,
            'message' => "patient has been created successfully",
        ]);
    }


    /**
     * get patient
     * @param $id
     * @return PatientResource
     * @author Mohamed Eldefrawy
     */
    public function getPatient($id)
    {
        return $this->patientService->get($id);
    }

    /**
     * @param Request $request
     * @return array
     * @author Ahmed Abdelaty
     */
    public function GetPatientsByClinic(Request $request)
    {
        return $this->patientService->GetPatientsByClinic($request->id);
    }


    /**
     * @param Request $request
     * @return string[]
     * @author Abdullah Hegab
     */
    public function isPatientExist(Request $request)
    {
        $phone = $request->phone;

        $user = User::where('name', '=', $phone)->get()->count();
        if ($user == 0) {
            return ["patient-State" => "False"];
        } else {
            return ["patient-State" => "True"];
        }
    }


}

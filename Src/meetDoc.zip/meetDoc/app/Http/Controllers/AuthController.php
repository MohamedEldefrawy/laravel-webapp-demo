<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginPostRequest;
use App\Http\Resources\AuthResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{

    // logout and destroy user token
    public function logout(Request $request)
    {
        auth()->user()->tokens()->delete();
        return [
            'message' => 'logged out'
        ];
    }

    // login
    public function login(LoginPostRequest $request)
    {
        if (!Auth::attempt($request->only('name', 'password'))) {
            return response([
                'message' => 'bad credentials'
            ], 401);
        }
        $user = Auth::user();


        return new AuthResource($user);
    }

}

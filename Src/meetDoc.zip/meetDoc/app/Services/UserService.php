<?php
namespace App\Services;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserService{
    public static function SetPassword(Request $request){
        //setting a new password
        //Ahmed Abdelaty
        //5 june
        if(isset($request['password'])){
            if(User::where('name', $request['phone'])->exists()){
                User::where('name', $request['phone'])
                ->update(['password' =>  Hash::make($request['password'])]);
            return response()->json(['status'=>true,'message'=>"password has been set successfully"]);
            }else{
                return response()->json(['status'=>false,'message'=>"wrong phone number"]);
            }
        }else{
            return response()->json(['status'=>false,'message'=>"no password has been passed"]);
        }
    }
}
?>
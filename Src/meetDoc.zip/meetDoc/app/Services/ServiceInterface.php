<?php

namespace App\Services;

interface ServiceInterface
{
    public function get_all();

    public function get($id);

    public function create($model);

    public function delete($id);

    public function update($id, $model);
}

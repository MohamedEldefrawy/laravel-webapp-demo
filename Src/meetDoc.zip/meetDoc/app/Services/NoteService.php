<?php

namespace App\Services;

use App\Http\Resources\NoteResource;
use App\Models\Note;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class NoteService implements ServiceInterface
{

    public function get_all()
    {
    }

    public function get($id)
    {

    }

    public function create($model)
    {
        // TODO: Implement create() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    public function update($id, $model)
    {
        // TODO: Implement update() method.
    }


    /**
     * @param $patientId
     * @return AnonymousResourceCollection
     * @author Mohamed Eldefrawy
     */
    public function getNotesOfPatient($patientId): AnonymousResourceCollection
    {
        return NoteResource::collection(Note::all()->where('patient_id', $patientId));
    }
}

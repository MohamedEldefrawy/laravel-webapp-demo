<?php

namespace App\Services;

use App\Dto\DocumentDto;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Storage;

class S3Service
{

    /**
     * @param $documents
     * @param $patientId
     * @param $uploadedBy
     * @return array
     * @author Mohamed Eldefrawy
     */
    public function uploadDocument($documents, $patientId, $uploadedBy): array
    {

        $documentService = new DocumentService();
        $documentDto = new DocumentDto();
        $urls = [];
        $fileNames = [];
        $fileExtensions = [];


        foreach ($documents as $document) {
            $path = Storage::disk('s3')->put('documents', $document);
            $fileNames[] = $path;
            $documentDto->setName($path);

            $fileExtensions[] = $document->extension();
            $documentDto->setType($document->extension());


            try {
                $path = Storage::disk('s3')->temporaryUrl($path, now()->addMinutes(10));
                $urls[] = $path;
                $documentDto->setLink($path);
                $documentDto->setPatientId($patientId);
                $documentDto->setUploadedBy($uploadedBy);
                $documentService->saveDocument($documentDto);
            } catch (S3Exception $err) {
                return [
                    "success" => false,
                    "message" => "Failed to upload file",
                    "error" => $err
                ];
            }
        }

        return [
            "success" => true,
            "urls" => $urls,
            "extension" => $fileExtensions,
            "file-name" => $fileNames,
        ];

    }
}

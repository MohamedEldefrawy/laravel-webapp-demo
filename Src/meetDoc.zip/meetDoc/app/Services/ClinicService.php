<?php

namespace App\Services;

use App\Http\Resources\ClinicResource;
use App\Models\Clinic;


class ClinicService implements ServiceInterface
{

    public function get_all()
    {
        // TODO: Implement get_all() method.
        $clinics = Clinic::all();
        return ClinicResource::collection($clinics);

    }

    public function get($id)
    {
        // TODO: Implement get() method.
    }

    public function create($model)
    {
        // TODO: Implement create() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    public function update($id, $model)
    {
        // TODO: Implement update() method.
    }
}

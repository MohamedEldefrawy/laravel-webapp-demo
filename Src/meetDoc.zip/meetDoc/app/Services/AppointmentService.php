<?php

namespace App\Services;

use App\Http\Resources\AppointmentResource;
use App\Models\Appointment;

class AppointmentService implements ServiceInterface
{

    public function get_all()
    {
        // TODO: Implement get_all() method.
        $appointments = Appointment::with(['doctor_service','patient'])->get();

        return  AppointmentResource::collection($appointments);
    }

    public function get($id)
    {
        // TODO: Implement get() method.
    }

    public function create($model)
    {
        // TODO: Implement create() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    public function update($id, $model)
    {
        // TODO: Implement update() method.
    }
}

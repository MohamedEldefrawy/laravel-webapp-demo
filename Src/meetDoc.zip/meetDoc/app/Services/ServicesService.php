<?php

namespace App\Services;

use App\Http\Resources\ServiceResource;
use App\Models\Service;

class ServicesService implements ServiceInterface
{

    public function get_all()
    {
        // TODO: Implement get_all() method.
        $services = Service::all();
        return ServiceResource::collection($services);
    }

    public function get($id)
    {
        // TODO: Implement get() method.
    }

    public function create($model)
    {
        // TODO: Implement create() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    public function update($id, $model)
    {
        // TODO: Implement update() method.
    }
}

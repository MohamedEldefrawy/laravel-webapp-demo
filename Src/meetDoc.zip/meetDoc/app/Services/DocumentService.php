<?php

namespace App\Services;

use App\Dto\DocumentDto;
use App\Http\Resources\DocumentsResource;
use App\Models\MedicalDocument;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class DocumentService
{
    /**
     * Craete Medical Document record in database
     * @param DocumentDto $documentDto
     * @return DocumentsResource
     * @author Mohamed Eldefrawy
     */
    public function saveDocument(DocumentDto $documentDto): DocumentsResource
    {
        $createdDocument = MedicalDocument::Create([
            'link' => $documentDto->getLink(),
            'type' => $documentDto->getType(),
            'name' => $documentDto->getName(),
            'uploaded_by' => $documentDto->getUploadedBy(),
            'patient_id' => $documentDto->getPatientId()
        ]);

        return new DocumentsResource($createdDocument);
    }

    /**
     * Return patient documents by patient id
     * @param $patientId
     * @return AnonymousResourceCollection
     * @author Mohamed Eldefrawy
     */
    public function getPatientDocuments($patientId): AnonymousResourceCollection
    {
        return DocumentsResource::collection(MedicalDocument::all()->where('patient_id', $patientId));

    }
}

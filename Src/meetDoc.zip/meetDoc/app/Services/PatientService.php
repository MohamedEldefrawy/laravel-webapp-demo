<?php

namespace App\Services;

use App\Http\Resources\CreatePatientResource;
use App\Http\Resources\PatientResource;
use App\Http\Resources\PatientsPerClinicResource;
use App\Models\Clinic;
use App\Models\Patient;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class PatientService implements ServiceInterface
{

    public function get_all()
    {
        // TODO: Implement get_all() method.
    }

    /**
     * @param $id
     * @return PatientResource
     * @author Mohamed Eldefrawy
     */
    public function get($id)
    {
        $selectedPatient = Patient::with(["user", "medicalDocuments", "symptoms"])
            ->find($id);
        return new PatientResource($selectedPatient);
    }

    /**
     * @param $model
     * @return CreatePatientResource
     * @author Mohamed Eldefrawy
     */
    public function create($model): CreatePatientResource
    {
        $checkIfEmailExists = User::where('email', $model->getEmail())->count();
        $checkIfNameExists = User::where('name', $model->getName())->count();


        if ($checkIfEmailExists > 0) {
            return new CreatePatientResource([
                "status" => false,
                "user" => null,
                "message" => "email already exists"
            ]);
        } else if ($checkIfNameExists > 0) {
            return new CreatePatientResource(
                [
                    "status" => false,
                    "user" => null,
                    "message" => "name already exists"
                ]);
        }

        $patientUser = User::create([
            "email" => $model->getEmail(),
            "name" => $model->getName(),
            "password" => Hash::make($model->getPassword())
        ]);

        $patient = Patient::create([
            "user_id" => $patientUser->id,
            "weight" => $model->getWeight(),
            "height" => $model->getHeight(),
            "gender" => $model->getGender(),
            "age" => $model->getAge(),
            "blood_type" => $model->getBloodType(),
            "first_name" => $model->getFirstName(),
            "last_name" => $model->getLastName(),
            "created_by" => $model->getCreatedBy()
        ]);

        $patientUser->assignRole("Patient");

        foreach (config('global.patientRolePermissions') as $permission) {
            $patientUser->givePermissionTo($permission);
        }

        return new CreatePatientResource(
            [
                "status" => true,
                "user" => $patient,
                "message" => "patient has been created successfully."
            ]);
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    public function update($id, $model)
    {
        // TODO: Implement update() method.
    }

    /**
     * @param CreatePatientRequest $request
     * @return array
     * @author Abdulla Hegab
     * @updated by Ahmed Abdelaty
     */
    public function GetPatientsByClinic($id)
    {
        $clinic = Clinic::with("clinicsPatients")->where('id', $id)->get()->first();
        $clinicPatients = $clinic->clinicsPatients;
        $patients = [];

        foreach ($clinicPatients as $clinicPatient) {
            if ($clinicPatient->patient->appointments->count() > 0) {
                $patients[] = new PatientsPerClinicResource($clinicPatient->patient);
            }
        }

        return ['patients' => $patients];
    }
}
